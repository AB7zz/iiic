import React from 'react'

const Cat = () => {
  return (
    <div>Cat</div>
  )
}

export default Cat